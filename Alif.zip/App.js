import React, {useState, useEffect} from "react";
import {ActivityIndicator, View, Image,   AppRegistry,} from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Mainnavigation from "./MainNavigation";
import RootStack from "./navigation/RootStack";
import { AuthContext } from "./components/context";
import SignInScreen from "./screens/SignInScreen";
import SignUpScreen from "./screens/SignUpScreen";
import Home from "./screens/Home";
import MainTabScreen from './navigation/BottomTabs'
import MoreScreen from "./screens/MoreScreen";


const RootStacks = createNativeStackNavigator();


export default function App() {
  // const [isLoading, setIsLoading] = React.useState(true);
  // const [userToken, setUserToken] = React.useState(null);
  // const authContext = React.useMemo(() => ({
  //   signIn: () => {
  //     setUserToken('fgk');
  //     setIsLoading(false);
  //   },
  //   signOut: () => {
  //     setUserToken(null);
  //     setIsLoading(false);
  //   },
  //   signUp: () => {
  //     setUserToken('fgk');
  //     setIsLoading(false);
  //   },
  // }));

  // useEffect(() =>{
  //   setTimeout(()=> {
  //     setIsLoading(false);
  //   }, 500);
  // }, []);

  // if(isLoading ) {
  //   return(
  //     <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
  //       <ActivityIndicator size="large"/>
  //     </View>
  //   );
  //   }


  return (
    // <AuthContext.Provider value={authContext}>
      <NavigationContainer>
        {/* { userToken !== null ? (
      <Mainnavigation /> 

        )
      :
      <RootStack />
      
      } */}
      
         <RootStacks.Navigator screenOptions={{headerShown: false}}>
        <RootStacks.Screen name="LoginScreen" component={SignInScreen} />
        <RootStacks.Screen name="SignUpScreen" component={SignUpScreen} />
        <RootStacks.Screen name="HomeScreen" component={Mainnavigation}/>
        {/* <RootStacks.Screen name="MoreScreen" component={ MainTabScreen}/>

        <RootStacks.Screen name="HomScreen" component={MoreScreen}/> */}

    </RootStacks.Navigator>
    </NavigationContainer>
    // </AuthContext.Provider>
  );
}
