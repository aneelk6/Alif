import React from "react";
import { Button, Image, Text, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import MyStack from "./screens/MoreScreen";
import Home from "./screens/Home";
import QuranScreen from "./screens/QuranScreen";
// import MainTabScreen from "./navigation/BottomTabs";
import Tashbih from "./screens/Tashbih";
import Healthscreen from "./screens/HealthScreen";
import WorshipScreen from "./screens/WorshipScreen";
import MoreScreen from "./screens/MoreScreen";
import Drawers from "./navigation/Drawer";
import Icon from 'react-native-vector-icons/Ionicons';

const Stack = createNativeStackNavigator();
const MainStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const MainTabScreen = () => (
  <Tab.Navigator initialRouteName="Home">
    <Tab.Screen
      name="."
      component={QuranScreen}
      options={{
        headerShown: false,
        tabBarLabel: "Quran",
        tabBarLabelStyle: {
          top: -5,
        },
        tabBarIcon: ({ focused }) => (
          <View>
            <Image
              source={require("./assets/img/quran.png")}
              resizeMode="contain"
              style={{
                height: 40,
                width: 40,
                tintColor: focused ? "#0080FE" : "gray",
              }}
            />
          </View>
        ),
      }}
    />
    <Tab.Screen
      name="Hadith"
      component={Healthscreen}
      options={{
        headerShown: false,
        tabBarLabel: "Hadith",
        tabBarLabelStyle: {
          top: -5,
        },
        tabBarIcon: ({ focused }) => (
          <View>
            <Image
              source={require("./assets/img/hadith.png")}
              resizeMode="contain"
              style={{
                height: 40,
                width: 40,
                tintColor: focused ? "#0080FE" : "gray",
              }}
            />
          </View>
        ),
      }}
    />
    <Tab.Screen
      name="Home"
      component={Home}
      options={{
        headerShown: false,
        tabBarLabel: "Home",
        tabBarLabelStyle: {
          top: -5
        },
        tabBarIcon: ({ focused }) => (
          <View>
            <Image
              source={require("./assets/img/home.png")}
              resizeMode="contain"
              style={{
                height: 40,
                width: 40,
                tintColor: focused ? "#0080FE" : "gray",
                tabBarActiveTintColor: "red",
              }}
            />
            {/* <Text style={{top: -10, fontSize: 12, textAlign: 'center'}}>Home</Text> */}
          </View>
        ),
      }}
    />
    <Tab.Screen
      name="Worship"
      component={WorshipScreen}
      options={{
        headerShown: false,
        tabBarLabel: "Worship",
        tabBarLabelStyle: {
          top: -5,
        },
        tabBarIcon: ({ focused }) => (
          <View>
            <Image
              source={require("./assets/img/worship.png")}
              resizeMode="contain"
              style={{
                height: 40,
                width: 40,
                tintColor: focused ? "#0080FE" : "gray",
              }}
            />
          </View>
        ),
      }}
    />
    <Tab.Screen
      name="More"
      component={MoreScreen}
      options={{
        headerShown: false,
        tabBarLabel: "More",
        tabBarLabelStyle: {
          top: -5,
        },
        tabBarIcon: ({ focused }) => (
          <View>
            <Image
              source={require("./assets/img/more.png")}
              resizeMode="contain"
              style={{
                height: 40,
                width: 40,
                tintColor: focused ? "#0080FE" : "gray",
              }}
            />
          </View>
        ),
      }}
    />
  </Tab.Navigator>
);

const Drawer = createDrawerNavigator();
function CustomDrawer({navigation}) {
  return (
    <Drawer.Navigator drawerContent={(props) => <Drawers {...props} />}>
      <Drawer.Screen
        name="`"
        component={MainTabScreen}
        options={{
          title: "",
          headerRight: () => (
            <View style={{ flexDirection: "row" }}>
              <Image
                source={require("./assets/img/bell.png")}
                resizeMode="cover"
                style={{
                  tintColor: "#fff",
                  height: 15,
                  width: "15%",
                }}
              />
              <Image
                source={require("./assets/img/setting.png")}
                resizeMode="cover"
                style={{
                  tintColor: "#fff",
                  height: 15,
                  width: "15%",
                }}
              />
            </View>
          ),
          headerTransparent: {
            position: "relative",
            backgroundColor: "transparent",
          },
        }}
      />
    </Drawer.Navigator>
  );
}


export default function Mainnavigation() {
  return (
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Drawer" component={CustomDrawer} 
            options={{
               headerLeft: () => (
                 <Icon.Button name="ios-menu" size={25}
                 color="white"
                 onpress={() => navigation.openDrawer()}
                 ></Icon.Button>
                ),
            }}
        />
        <Stack.Screen name="Drawers" component={MoreScreen} />
        <Stack.Screen name="Tasbeeh" component={Tashbih} />
        {/* <Stack.Screen name="HomeScreen" component={Home} /> */}
      </Stack.Navigator>
  );
}
